package parallelTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.sun.corba.se.impl.naming.pcosnaming.InternalBindingKey;

public class CrossBrowserScript {

	public String baseUrl = "https://www.amazon.in/";
    public WebDriver driver ; 

	@BeforeTest
	public void launchBrowser() throws Exception{
		//Check if parameter passed from TestNG is 'firefox'
		
		System.out.println("launching chrome browser"); 
			//set path to chromedriver.exe
			System.setProperty("webdriver.chrome.driver",".\\chromedrivers.exe");
			//create chrome instance
			driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
        driver.get(baseUrl);
        Reporter.log("launching url");
       // String expectedTitle = "Amazon Summer Sale: 4th - 7th May 2019";
        //String actualTitle = driver.getTitle();
        //Assert.assertEquals(actualTitle, expectedTitle);
	}
	
	@Test(priority = 0)
    public void firstTimeRegistration(){
//		 driver.findElement(By.xpath("//a[@id='nav-link-yourAccount']")).click() ;
//         String expected = "Amazon Sign In";
//         String actual = driver.getTitle();
//         Assert.assertEquals(actual, expected);
//         driver.findElement(By.xpath("//a[@id='createAccountSubmit']")).click();
//         String expected1 = "Amazon Registration";
//         String actual1 = driver.getTitle();
//         Assert.assertEquals(actual1, expected1);
//         driver.findElement(By.xpath("//input[@id='ap_customer_name']")).sendKeys("karishma123");
//         driver.findElement(By.xpath("//input[@id='ap_phone_number']")).sendKeys("8076413114");
//         driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys("karishmaarora578@gmail.com");
//         driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys("Telus@2124");
//         driver.findElement(By.xpath("//input[@id='continue']")).click();
//         String expectedTitle = "Amazon Summer Sale: 4th - 7th May 2019";
//         String actualTitle = driver.getTitle();
//         Assert.assertEquals(actualTitle, expectedTitle);
		
		Select drpDownCategory = new Select(driver.findElement(By.xpath("//select[@id='searchDropdownBox']")));
		drpDownCategory.selectByValue("Appliances");
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("sony tv remote control original");
		driver.findElement(By.xpath("//div[@class='nav-search-submit nav-sprite']//input[@class='nav-input']"));
		driver.findElement(By.xpath("//div[@class='s-result-list sg-row']//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//div[2]//div[2]//div[1]//div[1]//div[1]//div[1]//div[1]//h2[1]//a[1]//span[1]"));
		driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
		driver.findElement(By.xpath("//a[@id='hlb-ptc-btn-native']")).click();
		
    }
	
	 
//	 @Test(priority = 1)
//     public void loginFunctionality() {
//		 
//		 	String expected = "Amazon Sign In";
//        	 String actual = driver.getTitle();
//        	 Assert.assertEquals(actual, expected);
//			//Find user name
//			driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys("karishmam30@gmail.com");
//			driver.findElement(By.id("continue")).click();
//			driver.findElement(By.name("password")).sendKeys("Telus@2124");
//			driver.findElement(By.id("login")).click();
//			
//     }

	@AfterTest
    public void terminateBrowser(){
        driver.close();
    }

}
